# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 22:31:59 2017
test
"""
image = mpimg.imread('solidYellowCurve.jpg')
imshape = image.shape